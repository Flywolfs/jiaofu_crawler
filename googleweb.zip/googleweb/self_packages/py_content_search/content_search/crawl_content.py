# -*- coding:utf-8 -*-
from content_search import special_tail
import requests
from requests.adapters import HTTPAdapter
import sqlite3
import os
import re
import time
from cn_news_content_crawler import myboiler
import string
import csv
from en_news_content_crawler.finalized_model import king_crimson
import pdfkit
import traceback
import timeout_decorator

'''
该类执行:
1.按照中英文需要，将数据库中的负面新闻链接内容从html中提取
2.对提取的内容进行过滤，去除中英混合的情况
3.将内容保存至txt文件
'''
#正则表达式
TAIL_PATTERN = re.compile(r'.*[\.=-](.*)')
CN_PATTERN = re.compile(r'[\u4E00-\u9FA5]')
EN_PATTERN = re.compile(r'[A-Za-z]')
EN_PUNC = re.compile('[%s]' % re.escape(string.punctuation))
requests.adapters.DEFAULT_RETRIES = 5

config = {'browser_user_agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/'
                                '537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safar' 'i/537.36',
          'parser_class': 'lxml'}

headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36',
              'Connection': 'keep-alive'}

class HTMLContentRetrival():
    links = dict()
    excluded_web = []
    detail_list = []

    def __init__(self,logger):
        self.logger = logger

    #将title缩短至文件名限制长度内
    def validate_title(self, title, lang):
        rstr = r"[\s\/\\\:\*\?\"\<\>\|;]"  # '/ \ : * ? " < > |'
        new_title = re.sub(rstr, "_", title)
        if lang=="cn":
            if len(new_title) > 250:
                new_title = new_title[0:200]
            return new_title
        elif lang=="en":
            if len(new_title) > 100:
                new_title = new_title[0:50]
            return new_title

    #去除中英混合以及空行等
    def remove_useless(self, context=None, lang="en"):
        if lang == "en":
            context = CN_PATTERN.sub(r'', context)
            # 将文中开头结尾的空格和空行去掉
            context = re.sub(r"^\s+|^\n+|^\r+|\s+$|^\n+$|^\r+$", "", context)
            # 将文字之间的多余换行替换为单个换行
            context = re.sub(r"\s*\n+", "\n", context)
        elif lang == "cn":
            # 去除英文字母
            context = EN_PATTERN.sub(r'', context)
            # 去除英文标点
            context = EN_PUNC.sub(r'', context)
            # 将文中开头结尾的空格和空行去掉
            context = re.sub(r"^\s+|^\n+|^\r+|\s+$|^\n+$|^\r+$", "", context)
            # 将文字之间的多余换行替换为单个换行
            context = re.sub(r"\s*\n+", "\n", context)
        return context

    # 确认连接是否为文件形式的网页
    def varify_link(self, link, exclued_web):
        try:
            tail = re.search(TAIL_PATTERN,link).group(1)
            if tail in special_tail.DOC or tail in special_tail.DOW or tail in special_tail.MBX or tail in special_tail.PDF \
                    or tail in special_tail.RTF or tail in special_tail.XLS or tail in special_tail.DOCX \
                    or tail in special_tail.PPT or tail in special_tail.PPTX or tail in special_tail.TXT:
                return False
            else:
                for i in exclued_web:
                    if i in link:
                        return False
                return True
        except:
            return True

    def download_pdf_doc(self,link,special_tail,out):
        print("查看是否为special tail")
        try:
            tail = re.search(TAIL_PATTERN,link).group(1)
            if tail in special_tail:
                res = requests.get(link,headers=headers,verify=False,timeout=15)
                self.logger.info("获取Special tail文件"+link)
                with open(out+"."+tail, 'wb') as f:
                    f.write(res.content)
        except Exception as e:
            self.logger.exception(id)
            self.logger.exception(e)

    #保存链接内容是否获取过的状态
    def save_status(self, id=None, db=None):
        conn = sqlite3.connect(db)
        c = conn.cursor()
        # 更新数据库中link爬去状态
        c.execute("UPDATE tb_links SET if_crawled=\"True\" WHERE id=" + str(id))
        conn.commit()
        self.logger.info("状态保存成功" + str(id))

    #开始提取内容
    def start_retrival(self, db_path=None, file_folder=None, excluded_path = None, lang=None):
        self.load_excluded_web(path=excluded_path)
        self.load_db_records(path=db_path)
        self.set_filesystem(path=file_folder)
        for id in self.links:
            self.web_content_retrivaler(id=id,file_system=file_folder,db_path=db_path,lang=lang)
        return self.detail_list

    def load_excluded_web(self,path=None):
        excluded_f = open(path)
        excluded_f_csv = csv.reader(excluded_f)
        for i in excluded_f_csv:
            self.excluded_web.append(i[0])

    def load_db_records(self,path=None):
        conn = sqlite3.connect(path)
        c = conn.cursor()
        cursor = c.execute("SELECT * FROM tb_links")
        for item in cursor:
            #                     [keyword,link,title,if_crawled,news_time]
            self.links[item[0]] = [item[2], item[3], item[4], item[5], item[8]]
        conn.close()

    def set_filesystem(self,path=None):
        if not os.path.exists(path):
            os.makedirs(path)

    def web_content_retrivaler(self,id=None,file_system=None,db_path=None,lang=None):
        self.logger.info(time.strftime("%H:%M:%S", time.localtime()))
        record = self.links[id]
        if_crawled = record[3]
        start_time = ""
        try:
            if if_crawled == "False":
                link = record[1]
                if self.varify_link(link, self.excluded_web):
                    self.save_html(link,config['browser_user_agent'],file_system + "/" + str(id) + ".html")
                    self.save_html_pdf_from_file(file_system + "/" + str(id) + ".html", file_system + "/" + str(id) + ".pdf")
                    start_time = str(time.strftime("%a %b %d %H:%M:%S %Y", time.localtime()))
                    (sequential_result,orginal_len,filtered_len) = self.crawler(lang=lang,link=link)
                    if orginal_len != 0:
                        self.logger.info("*********")
                        self.logger.info(filtered_len / orginal_len)
                        self.logger.info("*********")
                    self.logger.info("获取内容完成" + str(id))
                    if sequential_result == [] or sequential_result == '':
                        self.logger.info("爬取网页内容为空")
                    else:
                        self.web_content_storager(id=id,file_system=file_system,sequential_result=sequential_result,row_record=record,start_time=start_time)
                    self.save_status(id=id, db=db_path)
                else:
                    self.download_pdf_doc(link, ['doc', 'DOC', 'docx', 'DOCX', 'pdf', 'PDF'], file_system + "/" + str(id))
                    self.logger.info("网站不符合需求，取消爬取" + str(id))
                    self.save_status(id=id, db=db_path)
            elif if_crawled == "True":
                self.logger.info("重复link" + str(id))
            elif if_crawled == "Null":
                self.logger.info("无记录comp:" + str(id))
        except Exception as e:
            self.logger.exception(id)
            self.logger.exception(e)

    def crawler(self,lang=None,link=None):
        s = requests.session()
        s.keep_alive = False
        sequential_result = None
        orginal_len = 0
        filtered_len = 0
        if lang == "en":
            sequential_result, wholeText, benchmark = king_crimson(Url=link, crawler_config=config)
            # crawler = JustextArticleExtract()
            # response = s.get(link, timeout=10)
            # sequential_result, wholetext = crawler.justext_execute(response)
            for i in range(0, len(sequential_result)):
                orginal_len += len(sequential_result[i])
                sec = self.remove_useless(context=sequential_result[i], lang="en")
                sequential_result[i] = sec
                filtered_len += len(sec)
        elif lang == "cn":
            my_boiler = myboiler.MyBoiler()
            sequential_result = my_boiler.my_boiler(link, 'ArticleExtractor')
            orginal_len = len(sequential_result)
            sequential_result = self.remove_useless(context=sequential_result, lang="cn")
            filtered_len = len(sequential_result)
        return (sequential_result,orginal_len,filtered_len)

    def web_content_storager(self,id=None,file_system=None,sequential_result=None,row_record=None,start_time=None):
        file_location = file_system + "/" + str(id) + ".txt"
        if not os.path.exists(file_location):
            f = open(file_location, 'w')
            if type(sequential_result) == type([]):
                result = ''
                for i in sequential_result:
                    result += i + '\r'
                f.write(result)
                # f.write(total_result)
                f.close()
                self.logger.info("写入文件完成" + str(id))
            else:
                f.write(sequential_result)
                # f.write(total_result)
                f.close()
                self.logger.info("写入文件完成" + str(id))
            # create new detail and insert into detail_list
            self.insert_keyword_detail(detail_list=self.detail_list, row_record=row_record,
                                       file_location=file_location,start_time=start_time)
        else:
            self.logger.info("重复内容" + str(id))

    def insert_keyword_detail(self,detail_list=None,row_record=None,file_location=None,start_time=None):
        keyword_exist = False
        result = {"news_title": row_record[2][:200], "link": row_record[1], "news_file_location": file_location,
                  "news_date": row_record[4],"crawl_start_time":start_time,"crawl_end_time":str(time.strftime("%a %b %d %H:%M:%S %Y", time.localtime()))}
        for detail in detail_list:
            if row_record[0] == detail["keyword"]:
                detail["result_list"].append(result)
                keyword_exist = True
        # if keyword doesn;t exist in current detail list, then append a new record to detail list
        if not keyword_exist:
            detail = {"keyword":row_record[0],"result_list":[result]}
            detail_list.append(detail)

    def save_html(self,url, config, out):
        res = requests.get(url, config,timeout=15)
        # print(res.content.decode('utf-8'))
        self.logger.info("%%%%%"+out+"%%%%%")
        with open(out, 'w') as f:
            f.write(res.content.decode('utf-8'))
    
    @timeout_decorator.timeout(10)
    def save_html_pdf_from_file(self, file, out):
        try:
            pdfkit.from_file(file, out)
        except Exception as e:
            self.logger.exception(e)
