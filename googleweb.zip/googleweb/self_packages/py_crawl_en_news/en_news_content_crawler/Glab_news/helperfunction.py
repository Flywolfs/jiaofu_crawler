from goose3 import Goose
import justext
from readability import Document
from html2text import HTML2Text
from selenium import webdriver
import re
import os.path as ospath
import time
import json
import requests
import random


def get_random_proxy(https_addr, http_addr):
    with open(http_addr, 'r') as f:
        http_proxies = f.readlines()
    with open(https_addr, 'r') as f:
        https_proxies = f.readlines()
    https_proxy = random.choice(https_proxies).strip()
    http_proxy = random.choice(http_proxies).strip()
    proxies = {'https_proxy': https_proxy, 'http_proxy': http_proxy}
    return proxies


class ReadFile:
    def __init__(self, name, address):
        self.name = name
        self.address = address
        self.result = list()

    def txt(self):
        with open(self.address + self.name, 'r', encoding='utf-8') as file:
            line = file.readline()
            while line:
                line = line.replace('\n','')
                self.result.append(line)
                line = file.readline()
            file.close()
        return self.result


## Goose crawler activation and
class GeneralItem:
    def __init__(self):
        self.cleaned_text = list()
        self.description = dict()
        self.meta_keywords = list()
        self.sourse_link = str()

    def jsonilze(self):
        item = dict()
        item['cleaned_text'] = self.cleaned_text
        item['description'] = self.description
        item['_meta_keywords'] = self.meta_keywords
        item['sourse_link'] = self.sourse_link
        return item


class JustextArticleExtract(GeneralItem):
    chinese_stoplist = []
    def justext_execute(self, response):
        paragraphs = justext.justext(response.content, justext.get_stoplist("English"))
        self.cleaned_text = list()
        textbody = ''
        for paragraph in paragraphs:
            if paragraph.cf_class is 'good':
                self.cleaned_text.append(paragraph.text)
                textbody = textbody + paragraph.text
        return self.cleaned_text, textbody

    def standardize(self):
        self.meta_keywords = ''
        self.description = ''
        self.sourse_link = ''
        return self.jsonilze()

    def save_to_local(self, ftype, data, name):
        if ftype is 'json':
            with open('result.json', 'a+', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            f.close()
        elif ftype is 'txt':
            with open(name + '.txt', 'w', encoding='utf-8') as f2:
                f2.write(data)
                f2.writelines('\n')
                print("success")
            f2.close()


class GooseArticleExtract(GeneralItem):
    def __init__(self, config):
        GeneralItem.__init__(self)
        self.goose_config = config
        self.g = Goose(self.goose_config)

    def goose_execute(self, url):
        ''' # potentially using proxy here
        except:
            self.free_up()
            self.config['http_proxies'] = str(self.rotate_proxy())
            self.recursive(self.config)
        '''
        metadata = self.g.extract(url=url)
        self.free_up()
        return metadata

    def standardized(self, metadata):
        self.sourse_link = metadata._final_url
        self.cleaned_text = metadata._cleaned_text
        self.description = metadata._meta_description
        self.meta_keywords = metadata._meta_keywords
        return self.jsonilze()

    def save_to_local(self, ftype, data, name):
        if ftype is 'json':
            with open('result.json', 'a+', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            f.close()
        elif ftype is 'txt':
            filename = name + '.txt'
            with open(name + '.txt', 'w', encoding='utf-8') as f2:
                f2.write(data)
                f2.writelines('\n')
                print("success")
            f2.close()

    def free_up(self):
        self.g.close()


class ReadabilityArticleExtract(GeneralItem):
    def __init__(self, file_encoding: str = None, second_delay: int = None):
        if file_encoding is None:
            self._file_encoding = "utf-8"
        else:
            self._file_encoding = file_encoding
        if second_delay is None:
            self._second_delay = 90
        else:
            self._second_delay = second_delay
        self._links_info = []

    # 根据link获取其浏览器渲染过后的html源码
    def get_html(self, source_link, browser):
        try:
            if browser is None:
                browser = webdriver.Chrome()
            browser.get(source_link)
            time.sleep(self._second_delay)
            html = browser.page_source
            #print(html)
            browser.close()
        except:
            response = requests.get(source_link)
            html = response.text
            if html is None or html == "":
                print("get html error")
                html = ""
        return html

    # 验证保存文件时的title
    def validate_title(self, title):
        rstr = r"[\s\/\\\:\*\?\"\<\>\|]"  # '/ \ : * ? " < > |'
        new_title = re.sub(rstr, "_", title)
        if len(new_title) > 255:
            new_title = new_title[0:255]
        return new_title

    def get_title(self, html):
        if html != "":
            doc = Document(html)
            title = doc.title()
        else:
            title = ""
        return title

    def get_clean_text(self, html):
        if html != "":
            doc = Document(html)
            h = HTML2Text()
            h.ignore_images = True
            h.ignore_links = True
            clean_text = h.handle(doc.summary())
        else:
            clean_text = ""
        return clean_text

    def fit(self, source_links: list, browser: [webdriver.Edge, webdriver.Chrome,
                                                webdriver.Firefox, webdriver.Opera,
                                                webdriver.PhantomJS, webdriver.Safari,
                                                webdriver.Android, webdriver.Ie] = None):
        for link in source_links:
            html = self.get_html(link, browser)
            title = self.get_title(html)
            file_title = self.validate_title(title)
            clean_text = self.get_clean_text(html)
            link_info = dict()
            link_info["html"] = html
            link_info["title"] = title
            link_info["file_title"] = file_title
            link_info["clean_text"] = clean_text
            link_info["source_link"] = link
            self._links_info.append(link_info)
        return self

    def fit_transform(self, source_links: list, browser: [webdriver.Edge, webdriver.Chrome,
                                                          webdriver.Firefox, webdriver.Opera,
                                                          webdriver.PhantomJS, webdriver.Safari,
                                                          webdriver.Android, webdriver.Ie] = None):
        self.fit(source_links, browser)
        return self._links_info

    def fit_jsonlize(self, source_links: list, browser: [webdriver.Edge, webdriver.Chrome,
                                                         webdriver.Firefox, webdriver.Opera,
                                                         webdriver.PhantomJS, webdriver.Safari,
                                                         webdriver.Android, webdriver.Ie] = None):
        self.fit(source_links, browser)
        return json.dumps(self._links_info)

    def fit2file(self, source_links, dirpath, browser: [webdriver.Edge, webdriver.Chrome,
                                                        webdriver.Firefox, webdriver.Opera,
                                                        webdriver.PhantomJS, webdriver.Safari,
                                                        webdriver.Android, webdriver.Ie] = None):
        i = 0
        for link in source_links:
            html = self.get_html(link, browser)
            title = self.get_title(html)
            file_title = self.validate_title(title)
            clean_text = self.get_clean_text(html)
            link_info = dict()
            link_info["html"] = html
            link_info["title"] = title
            link_info["file_title"] = file_title
            link_info["clean_text"] = clean_text
            link_info["source_link"] = link
            self._links_info.append(link_info)
            filepath = ospath.join(dirpath, file_title + "-id-" + str(i))
            with open(filepath, mode="w", encoding=self._file_encoding) as f:
                try:
                    f.write(json.dumps(link_info))
                except:
                    print("file IO error")
        return self
