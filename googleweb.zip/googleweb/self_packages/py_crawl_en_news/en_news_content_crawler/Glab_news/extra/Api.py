from en_news_content_crawler.Glab_news.helperfunction import GeneralItem, GooseArticleExtract, JustextArticleExtract, ReadabilityArticleExtract
from goose3.text import StopWordsChinese
GItem = GeneralItem()
import requests

## justext demo for English pages
link = 'https://www.latimes.com/opinion/la-xpm-2014-apr-07-la-ol-mpaa-lawsuit-against-megaupload-kim-dotcom-20140407-story.html'
links = 'https://www.foxnews.com/politics/ross-perot-donated-to-trumps-reelection-campaign-before-death-report'
'''J = JustextArticleExtract()
response = requests.get(links)
sequential_result, wholetext = J.justext_execute(response)
print("hell no")
'''
## goose demo for Chinese pages, need to import StopWordsChinese
config = {'browser_user_agent': 'Mozilla', 'parser_class':'soup', 'stopwords_class': StopWordsChinese}
G = GooseArticleExtract(config)
metadata = G.goose_execute(link)
print(metadata._cleaned_text)
print("hello")

'''
## goose demo for Enlish pages
config = {'browser_user_agent': 'Mozilla', 'parser_class':'soup'}
G = GooseArticleExtract(config)
metadata = G.goose_execute(link)
print("hello")

## readability-lxml demo
R = ReadabilityArticleExtract(second_delay=3)
l = list()
l.append(link)
info = R.fit_transform(l)
print(info[0]['clean_text'])
print("hell no")
'''
