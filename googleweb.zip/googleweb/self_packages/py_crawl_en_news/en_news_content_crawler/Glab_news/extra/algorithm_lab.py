from bs4 import BeautifulSoup
from bs4.element import Comment
import re


# to cluster results based on focus_rate and filtering_rate
class Judge:
    def __init__(self):
        self.total = list()
        self.good_to_use = list()
        self.not_bad_to_use = list()

        self.bad_page = list()
        self.bad_network = list()
        self.tool_failure = list()
        self.bad_server = list()
        self.unexpected = list()

    # clustering function
    def rolling_stone(self, seq_res, wholetext, benchmark, url):
        self.total.append(url)
        if isinstance(benchmark, dict):
            if benchmark['focus_rate'] >= 0.6:
                self.good_to_use.append({'seq_res': seq_res, 'wholetext': wholetext, 'url': url})
            elif benchmark['focus_rate'] + benchmark['filtering_rate'] >= 0.7:
                word_count = wholetext.split(' ')
                if len(word_count) > 30:
                    self.not_bad_to_use.append({'seq_res': seq_res, 'wholetext': wholetext, 'url': url})
            else:
                self.bad_page.append({'seq_res': seq_res, 'wholetext': wholetext, 'url': url})
        elif isinstance(benchmark, str):
            if benchmark == 'tool':
                self.tool_failure.append({'seq_res': seq_res, 'wholetext': wholetext, 'url': url})
            elif benchmark == 'network':
                self.bad_network.append(url)
            elif benchmark == 'server':
                self.bad_server.append(url)
            else:
                self.unexpected.append(url)


# to roughly filter the html non-text tag, and get plain result
class PureText:
    @staticmethod
    def tag_visible(element):
        if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
            return False
        if isinstance(element, Comment):
            return False
        return True

    def text_from_html(self, body):
        soup = BeautifulSoup(body, 'html.parser')
        texts = soup.findAll(text=True)
        visible_texts = list(filter(self.tag_visible, texts))
        res = []
        for instance in visible_texts:
            if re.findall('[A-Za-z]', instance):
                res.append(instance.strip())
        return ' '.join(res)

    @staticmethod
    def remove_void(sentence):
        return len(sentence)>0


# avoid processing
def filtering_url(url, suffix_list):
    url_section = url.split('.')
    suffix = url_section[len(url_section)-1]
    if suffix not in suffix_list:
        return 1
    else:
        return -1


# get first two sentences of the page as the begin
# get last two sentences of the page as the end
def deputy(contents: 'list'):
    try:
        sen1 = contents[0] + contents[1]
        sen2 = contents[len(contents)-1] + contents[len(contents)-2]
        start = sen1.split(',')
        end = sen2.split(',')
        return start, end
    except:
        return [], []


def evaluation_v1(bodygraph: 'str', start: 'list', end: 'list'):
    if not (len(start) and len(end)):
        return 0
    else:
        string_process = Kmp()
        start_loc = list()
        end_loc = list()
        # locate start in the body paragraph
        for s0 in start:
            string_process.next_table(s0)
            start_loc.append(string_process.kmp_match(s=bodygraph, p=s0))
        # locate end in the body paragraph
        for e0 in end:
            string_process.next_table(e0)
            end_loc.append(string_process.kmp_match(s=bodygraph, p=e0))
        begin = min(start_loc)
        end = max(end_loc)
        return (end - begin + 1) / len(bodygraph), begin, end


def evaluation_v2(bodygraph: 'str', start: 'list', end: 'list'):
    if not (len(start) and len(end)):
        return 0, 0, 0
    else:
        string_process = Kmp()
        start_loc = list()
        end_loc = list()
        # locate start in the body paragraph
        for s0 in start:
            if s0.find(' ') >= 0:
                string_process.next_table(s0)
                start_loc.append(string_process.kmp_match(s=bodygraph, p=s0))
        # locate end in the body paragraph
        for e0 in end:
            if e0.find(' ') >= 0:
                string_process.next_table(e0)
                end_loc.append(string_process.kmp_match(s=bodygraph, p=e0))
        begin = min(start_loc)
        end = max(end_loc)
        return (end - begin + 1) / len(bodygraph), begin, end


class Kmp:
    def kmp_match(self, s, p):
        m = len(s)
        n = len(p)
        cur = 0
        table = self.next_table(p)
        while cur <= m - n:
            for i in range(n):
                if s[i + cur] != p[i]:
                    cur += max(i - table[i - 1], 1)
                    break
            else:
                return cur
        return False

    # next table
    def next_table(self, p):
        # partial_table("ABCDABD") -> [0, 0, 0, 0, 1, 2, 0]
        prefix = set()
        suffix = set()
        ret = [0]
        for i in range(1, len(p)):
            prefix.add(p[:i])
            suffix = {p[j:i + 1] for j in range(1, i + 1)}
            ret.append(len((prefix & suffix or {''}).pop()))
        return ret