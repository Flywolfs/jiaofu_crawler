# Text-extraction 
## Algorithms and demo
1. GooseArticleExtract(config)
    * goose_execute(url)
    * save_to_local(ftype, data)
    * free_up()
2. JustextArticleExtract()
    * justext_execute(response)
    * save_to_local(ftype, data)
3. ReadabilityArticleExtract()
    * fit(source_links:list,browser)
    * fit_transform(source_links:list,browser) return list(dict)
    * fit_jsonlize(source_links:list,browser) return json str
    * fit2file(source_links:list,dirpath,browser) save json to file
    * browser need webdriver(download from network such as Chromedriver)
4. [API easy-run](https://github.com/another1s/SummerIntern/blob/master/Glab_news/extra/Api.py)