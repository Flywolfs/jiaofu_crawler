from en_news_content_crawler.Glab_news.helperfunction import *
import time
from en_news_content_crawler.Glab_news.extra.algorithm_lab import filtering_url, evaluation_v2, deputy, PureText, Judge
import requests

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/'
                  '537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safar'
                  'i/537.36',
}

config = {'browser_user_agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/'
                                '537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safar' 'i/537.36',
          'parser_class': 'lxml'}


invalid_url_suffix = ['doc', 'DOC', 'docx', 'DOCX', 'pdf', 'PDF', 'download', 'DOWNLOAD',
                      'rtf', 'RTF', 'mbx', 'MBX', 'xls', 'XLS', 'ppt', 'PPT',
                      'pptx', 'PPTX']


proxies = {'https': 'https://176.215.237.135:61945'}


def king_crimson(Url,crawler_config):
    res = filtering_url(url=Url, suffix_list=invalid_url_suffix)
    if res:
        try:
            response = requests.get(Url, crawler_config['browser_user_agent'],timeout=15)
            p = PureText()
            body = p.text_from_html(body=response.content)
            time.sleep(2)
            benchmark = {}
            J = JustextArticleExtract()
            sequential_result0, wholetext0 = J.justext_execute(response)
            res_J = J.standardize()
            G = GooseArticleExtract(crawler_config)
            metadata = G.goose_execute(Url)
            res_G = G.jsonilze()
            if len(metadata.cleaned_text) + len(wholetext0) > 0:
                if len(metadata.cleaned_text) >= len(wholetext0):
                    sequential_result = metadata.cleaned_text.split('\n')
                    start, end = deputy(list(filter(PureText.remove_void, sequential_result)))
                    wholetext = metadata.cleaned_text
                    acc, b, e = evaluation_v2(bodygraph=body, start=start, end=end)
                    if acc == 0:
                        return [], 'webpage contains insufficient text', {}
                    else:
                        benchmark['focus_rate'] = acc
                        text = wholetext.replace('\n', '')
                        benchmark['filtering_rate'] = len(text) / len(body)
                        print("goose")
                        return list(filter(PureText.remove_void, sequential_result)), wholetext, benchmark
                else:
                    wholetext = wholetext0
                    sequential_result = sequential_result0
                    start, end = deputy(sequential_result0)
                    acc, b, e = evaluation_v2(bodygraph=body, start=start, end=end)
                    if acc == 0:
                        return [], 'webpage contains insufficient text', {}
                    else:
                        benchmark['focus_rate'] = acc
                        text = wholetext.replace('\n', '')
                        benchmark['filtering_rate'] = len(text) / len(body)
                        print('justext')
                        return list(filter(PureText.remove_void, sequential_result)), wholetext, benchmark
            else:
                if len(body):
                    return [], body, 'tool'
                else:
                    return [], 'fail to extract text from given url', 'weird'

        except Exception as e:
            print(e)
            return [], 'connection failed', 'network'
    else:
        return [], 'invalid url address', 'server'

url = "https://www.theedgemarkets.com/article/timeline-jho-low%E2%80%99s-corporate-and-financial-wheeling-and-dealing-using-us183-billion-belonged"
seq_res, wholeText, benchmark = king_crimson(Url=url, crawler_config=config)
# with open('namelist.txt', 'r', encoding='utf-8') as f:
#     rows = f.readlines()
#     J = Judge()
#     for row in rows:
#         splited_row = row.split('%')
#         company_name = splited_row[0]
#         number = splited_row[1].split(' ')[0]
#         url = splited_row[1].split(' ')[1]
#         seq_res, wholeText, benchmark = king_crimson(Url=url, crawler_config=config)
#         w = wholeText.replace("\n", '')
#         J.rolling_stone(seq_res=seq_res, wholetext=wholeText, benchmark=benchmark, url=url)
#
#         if len(J.total) % 50 == 0:
#             good = len(J.good_to_use)
#             not_bad = len(J.not_bad_to_use) * 0.9
#             raw = len(J.tool_failure)
#             total = len(J.total)
#             weird = len(J.bad_page)
#
#             print('url available rate:', (good+not_bad+0.7*raw)/total)
#             print('acceptable rate:', (good+not_bad)/(good+not_bad+weird))
#         # if len(benchmark):
#         #     print(benchmark)
#         # if len(seq_res):
#         #     print(seq_res)
#         # print(w, '\n')
