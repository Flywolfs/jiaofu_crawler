# DefaultExtractor XX
# ArticleExtractor # Support Chinese
# ArticleSentencesExtractor # Almost One Sentence a line
# KeepEverythingExtractor XX
# KeepEverythingWithMinKWordsExtractor XX
# LargestContentExtractor
# NumWordsRulesExtractor X # Include some comments
# CanolaExtractor X # Include some front-end dynamic elements
from boilerpipe.extract import Extractor

class MyBoiler():
    def __init__(self):
        pass

    def my_boiler(self, url=None,strategy='ArticleExtractor'):
        # print('------ Start Program ------')
        # print(strategy)
        # print('------ Extract Text ------')
        return Extractor(extractor=strategy, url=url).getText()
        # extractor = Extractor(extractor=strategy, url=url, kMin=1) # KeepEverythingWithMinKWordsExtractor, (default)kMin=1
        # print(Extractor(extractor=strategy, url=url).getText())
        # print('------ Finish ------')

