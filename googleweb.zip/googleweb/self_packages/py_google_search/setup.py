from setuptools import find_packages,setup
setup(
    name = 'google_search',
    version = '0.3',
    packages = find_packages(),
)
