

def test1(a=None,b=None):
    if a:
        print(a)
    if b:
        print(b)

test1(a=1,b=1)