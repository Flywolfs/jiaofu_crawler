# coding=utf-8
import os
import time
import random
import sqlite3

# 查看是否订单被下载
def if_downloaded():
    pass

# 读取数据库，每一条数据获取公司名和orderid,执行scrapy
conn = sqlite3.connect('order.db')
c = conn.cursor()
print("数据库打开成功")
cursor = c.execute("SELECT * FROM order_comp")
orders = []
for row in cursor:
    orders.append([row[0],row[1],row[2]])
conn.close()
for i in orders:
    # row[2]是if_downloaded列
    if i[2] == None or i[2] == "False":
        #  row[1]是comp_name列
        comp_name = i[1]
        order_id = i[0]
        os.system('scrapy crawl company_registry_downloader -a compname=\"' + comp_name + '\" -a orderno=\"' + order_id + '\"')
        # 每个公司爬取时间间隔10-15秒，降低服务器压力
        time.sleep(random.randrange(5, 8))
    elif i[2] == "True":
        print("公司:" + i[1] + "　的文件已经被下载")