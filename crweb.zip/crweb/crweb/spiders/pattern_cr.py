import re

cookie_p = re.compile(r'JSESSIONID=(.*); path=/')
route_p = re.compile(r'ROUTEID=\.(.*); path=/')