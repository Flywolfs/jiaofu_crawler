# coding=utf-8
import scrapy
import re
import os
import sqlite3
class Check_Exist_Spider(scrapy.Spider):
    name = "company_check"

    # =================Constant==================
    SEARCH_SUCC = "Welcome to ICRIS!"
    SEARCH_CONC = "Sorry, concurrent access is not allowed!"
    NO_RESULT = "NO MATCHING RECORD FOUND FOR THE SEARCH INFORMATION INPUT!"
    TEMP_FILE = "/home/ubuntu/vb_migrate/server_migrate/predeploy/data/contents/tempfile/check_comp_exist/"
    # =================regular expression==================
    set_cookie_p = re.compile(r'JSESSIONID=(.*); path=/')
    set_route_p = re.compile(r'ROUTEID=\.(.*); path=/')
    cookie_p = re.compile(r'.*JSESSIONID=(.*)')
    route_p = re.compile(r'.*ROUTEID=\.(.*)')

    def __init__(self,compNum=None,*args, **kwargs):
        super(Check_Exist_Spider, self).__init__(*args, **kwargs)
        self.compNum = compNum


    def start_requests(self):
        print("公司编号:"+self.compNum)
        start_url = 'https://www.icris.cr.gov.hk/csci/login_i.do'
        headers = {
                   'Host': 'www.icris.cr.gov.hk',
                   'Origin': 'https://www.icris.cr.gov.hk',
                   'Referer': 'https://www.icris.cr.gov.hk/csci/login_i.jsp',
                   }

        login_formdata = {
            'loginType': 'iguest', 'OPT_01': '0','OPT_02': '0', 'OPT_03': '0','OPT_04': '0', 'OPT_05': '0', 'OPT_06': '0',
            'OPT_07': '0','OPT_08': '0', 'CHKBOX_09': 'false', 'OPT_09': '1'
        }

        yield scrapy.FormRequest(url=start_url,headers=headers,formdata=login_formdata,callback=self.parse_login)

    def parse_login(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print ("自动登录成功")
            cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
            route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
            self.cookie = self.set_cookie_p.search(cookie_src).group(1)
            print("爬取到的登录页Cookie: " + self.cookie)
            self.route = self.set_route_p.search(route_src).group(1)
            print("爬取到的登录页Route: "+self.route)
            # 下一项需要搜索公司名称
            self.next_url = "https://www.icris.cr.gov.hk/csci/cps_criteria.do"
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': 'https://www.icris.cr.gov.hk/csci/cps_criteria.jsp',
                       'Cookie':'web.country=US; web.language=en; ROUTEID=.'+self.route+'; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID='+self.cookie
                       }
            search_formdata = {
                "nextAction":"search_company_name", "searchPage":"True", "DPDSInd":"true","searchMode":"BYCRNO", "radioButton":"BYCRNO",
                "CRNo":self.compNum, "mode":"EXACT NAME", "showMedium":"true", "language":"en", "page":"1"
            }
            yield scrapy.FormRequest(url=self.next_url,headers=headers,formdata=search_formdata,callback=self.parse_check)
        elif self.SEARCH_CONC in body_text:
            print("ERROR:重复登录被网站拒绝")
        else:
            print("ERROR:自动登录失败，请检查请求体")

    def parse_check(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            if response.headers.getlist("Set-Cookie") == []:
                cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
                splited_cookie_src = cookie_src.split(";")
                for i in splited_cookie_src:
                    if "JSESSIONID=" in i:
                        self.cookie = self.cookie_p.search(i).group(1)
                        print("爬取到的搜索公司信息页Cookie: " + self.cookie)
                    elif "ROUTEID" in i:
                        self.route = self.route_p.search(i).group(1)
                        print("爬取到的搜索公司信息页Route: " + self.route)
            else:
                cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
                route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
                self.cookie = self.set_cookie_p.search(cookie_src).group(1)
                print("爬取到的搜索公司信息页Cookie: " + self.cookie)
                self.route = self.set_route_p.search(route_src).group(1)
                print("爬取到的搜索公司信息页Route: " + self.route)
            if self.NO_RESULT in body_text:
                print("公司不存在")
                result = {"exist": False, "company_num": self.compNum, "company_name": "", "company_type": ""}
                # 输出temp file
                if not os.path.exists(self.TEMP_FILE + self.compNum):
                    f = open(self.TEMP_FILE + self.compNum, 'w')
                    f.write(str(result))
                    f.close()
            else:
                print("公司存在")
                result = {"exist":True,"company_num":self.compNum,"company_name":"","company_type":""}
                #输出temp file
                if not os.path.exists(self.TEMP_FILE + self.compNum):
                    f = open(self.TEMP_FILE+self.compNum,'w')
                    f.write(str(result))
                    f.close()
        elif self.SEARCH_CONC in body_text:
            print("ERROR:重复登录被网站拒绝")
        else:
            print("ERROR:自动登录失败，请检查请求体")
