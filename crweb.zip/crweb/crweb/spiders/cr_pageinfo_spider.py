# -*- encoding: utf-8 -*-
import scrapy
import sqlite3
from lxml import etree
import os
import re
import traceback
import json

# fix bug38 support API to crawl page info
class CR_Pageinfo_Spider(scrapy.Spider):
    name = "cr_page_info_spider"

    # =================Constant==================
    SEARCH_SUCC = "Welcome to ICRIS!"
    SEARCH_CONC = "Sorry, concurrent access is not allowed!"
    SHOPCART_SUCC = "The item you just ordered has been successfully added to your shopping cart."
    NO_RESULT = "NO MATCHING RECORD FOUND FOR THE SEARCH INFORMATION INPUT!"
    BUY_SUCC = "Please note down the following number(s) or print / save this page for record."
    LOW_BALANCE = 50

    # =============regular expression============
    set_cookie_p = re.compile(r'JSESSIONID=(.*); path=/')
    set_route_p = re.compile(r'ROUTEID=\.(.*); path=/')
    cookie_p = re.compile(r'.*JSESSIONID=(.*)')
    route_p = re.compile(r'.*ROUTEID=\.(.*)')
    balance_p = re.compile(r'HK\$(.*)\.')
    empty_replace = re.compile(r"[\r\t\n:]")

    # ==================public variables==================
    cookie = ""
    next_url = ""
    route = ""

    # 账号数据库
    account_db = "/home/ubuntu/vb_migrate/server_migrate/predeploy/data/static/account.db"
    # 临时文件
    temp_file = "/home/ubuntu/vb_migrate/server_migrate/predeploy/data/contents/tempfile/onlineView/"

    download_root_path = "/home/ubuntu/vb_migrate/server_migrate/predeploy/data/contents/gov/"

    cr_num = ""

    comp_name_en = ""

    account = ""

    password = ""

    order_no = ""

    account_balance = 0

    # Code
    BUYSUCC = 200
    DUPLOGIN = 401
    LOGINFAIL = 402
    NOCOMP = 403
    CHECKCOMPFAIL = 404
    BOOKCOMPFAIL = 405
    PAYCOMPFAIL = 406
    VIEWONLINEFAIL = 407
    LOWBALANCE = 408

    def __init__(self,cr_num=None,comp_name_en=None,*args, **kwargs):
        super(CR_Pageinfo_Spider, self).__init__(*args, **kwargs)
        self.cr_num = cr_num
        self.comp_name_en = comp_name_en

    def start_requests(self):
        print("CR Number is:"+str(self.cr_num)+" Company name:"+self.comp_name_en)
        if self.get_icris_account():
            start_url = 'https://www.icris.cr.gov.hk/csci/login_s.do'
            headers = {
                'Host': 'www.icris.cr.gov.hk',
                'Origin': 'https://www.icris.cr.gov.hk',
                'Referer': 'https://www.icris.cr.gov.hk/csci/login_s.jsp',
            }

            login_formdata = {
                'loginType': 'subscriber', 'username': self.account, 'password': self.password, 'OPT_01': '0',
                'OPT_02': '0', 'OPT_03': '0', 'OPT_04': '0', 'OPT_05': '0', 'OPT_06': '0', 'OPT_07': '0',
                'OPT_08': '0', 'CHKBOX_09': 'false', 'OPT_09': '1'
            }

            yield scrapy.FormRequest(url=start_url, headers=headers, formdata=login_formdata, callback=self.parse_login)
        else:
            # 2020-02-17 TODO 对于找不到可用账户时的操作 bug43
            pass

    def parse_login(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print ("自动登录成功")
            cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
            route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
            self.cookie = self.set_cookie_p.search(cookie_src).group(1)
            print("爬取到的登录页Cookie: " + self.cookie)
            self.route = self.set_route_p.search(route_src).group(1)
            print("爬取到的登录页Route: "+self.route)
            # 下一项查看在线信息购买信息
            self.next_url = "https://www.icris.cr.gov.hk/csci/cps_criteria.do"
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': 'https://www.icris.cr.gov.hk/csci/cps_criteria.jsp',
                       'Cookie':'web.country=US; web.language=en; ROUTEID=.'+self.route+'; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID='+self.cookie
                       }
            search_formdata = {
                "nextAction": "cps_criteria",
                "searchPage": "True",
                "DPDSInd": "true",
                "searchMode": "BYCRNO",
                "radioButton": "BYCRNO",
                "CRNo": self.cr_num,
                "mode": "EXACT + NAME",
                "showMedium": "true",
                "language": "en",
                "page": "1"
            }
            yield scrapy.FormRequest(url=self.next_url,headers=headers,formdata=search_formdata,callback=self.parse_view_online_check)
        elif self.SEARCH_CONC in body_text:
            result = {"reason": "duplicate login"}
            self.save_result(code=self.DUPLOGIN, content=result)
            print("ERROR:重复登录被网站拒绝")
            self.update_icris_account()
        else:
            result = {"reason": "login failed"}
            self.save_result(code=self.LOGINFAIL, content=result)
            print("ERROR:自动登录失败，请检查请求体")
            self.update_icris_account()

    def parse_view_online_check(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            if self.NO_RESULT not in body_text:
                print("该公司存在且可继续在线查看")
                if response.headers.getlist("Set-Cookie") == []:
                    cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
                    splited_cookie_src = cookie_src.split(";")
                    for i in splited_cookie_src:
                        if "JSESSIONID=" in i:
                            self.cookie = self.cookie_p.search(i).group(1)
                            print("爬取到的展示公司文件页Cookie: " + self.cookie)
                        elif "ROUTEID" in i:
                            self.route = self.route_p.search(i).group(1)
                            print("爬取到的展示公司文件页Route: " + self.route)
                else:
                    cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
                    route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
                    self.cookie = self.set_cookie_p.search(cookie_src).group(1)
                    print("爬取到的展示公司文件页Cookie: " + self.cookie)
                    self.route = self.set_route_p.search(route_src).group(1)
                    print("爬取到的展示公司文件页Route: " + self.route)
                self.next_url = "https://www.icris.cr.gov.hk/csci/viewOnline.do"
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': 'https://www.icris.cr.gov.hk/csci/cps_module.do',
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                search_formdata = {
                    "searchKey":"company+particular+search,cr+no+is:"+self.cr_num,
                    "itemDesc":"company+particular+search,cr+no+is:"+self.cr_num,
                    "productCode":"CPS",
                    "moduleName":"cps_criteria",
                    "crNo":self.cr_num,
                    "DPDSInd":"true"
                }
                yield scrapy.FormRequest(url=self.next_url, headers=headers, formdata=search_formdata,
                                            callback=self.parse_view_online_book)
            else:
                print("没查到公司记录，crno:"+self.cr_num+" 准备退出")
                result = {"reason": "no such company record"}
                self.save_result(code=self.NOCOMP, content=result)
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': self.next_url,
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
                yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)
        else:
            print("parse_view_online_check失败，准备退出")
            result = {"reason": "parse_view_online_check failed"}
            self.save_result(code=self.CHECKCOMPFAIL, content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

    def parse_view_online_book(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print("预定该公司")
            if response.headers.getlist("Set-Cookie") == []:
                cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
                splited_cookie_src = cookie_src.split(";")
                for i in splited_cookie_src:
                    if "JSESSIONID=" in i:
                        self.cookie = self.cookie_p.search(i).group(1)
                        print("爬取到的展示公司文件页Cookie: " + self.cookie)
                    elif "ROUTEID" in i:
                        self.route = self.route_p.search(i).group(1)
                        print("爬取到的展示公司文件页Route: " + self.route)
            else:
                cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
                route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
                self.cookie = self.set_cookie_p.search(cookie_src).group(1)
                print("爬取到的展示公司文件页Cookie: " + self.cookie)
                self.route = self.set_route_p.search(route_src).group(1)
                print("爬取到的展示公司文件页Route: " + self.route)
            # TODO 测试页面不同的展示方式，目前发现两种，测试后再对余额检测做判断
            order_table = response.xpath('//form[@name="payViewOnline"]/table//td//font[@class="sameasbody"]/text()').getall()
            self.order_no = order_table[1]
            # order_price = int(float(order_table[4].lstrip("\r\n ").rstrip("\r\n ")))
            print("order no 是："+self.order_no)
            # print("订单价格是:"+str(order_price))
            balance = response.xpath('//td[contains(@colspan,"3") and contains(@width,"80%")]//text()').getall()[1]
            balance_str = self.balance_p.search(balance).group(1)
            balance_int = int(balance_str.replace(",", ""))
            print("余额还有:"+str(balance_int))
            # if balance_int >= order_price+50:
            print("余额充足，即将购买")
            self.next_url = "https://www.icris.cr.gov.hk/csci/viewOnlinePay.do"
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': 'https://www.icris.cr.gov.hk/csci/viewOnline.do',
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            search_formdata = {
                "orderNo": self.order_no,
                "toPay": "true",
                "DPDSInd": "true",
                "nextpage": "null",
                "sCRNo": self.cr_num,
                "unpaid": "true",
                "nextAction": "cps_criteria",
                "searchPage": "True"
            }
            yield scrapy.FormRequest(url=self.next_url, headers=headers, formdata=search_formdata,
                                     callback=self.parse_view_online_pay)
            # else:
            #     print("余额不足，请充值")
            #     result = {"reason": "low balance"}
            #     self.save_result(code=self.LOWBALANCE, content=result)
            #     headers = {'Host': 'www.icris.cr.gov.hk',
            #                'Origin': 'https://www.icris.cr.gov.hk',
            #                'Referer': self.next_url,
            #                'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
            #                }
            #     self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            #     yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)
        else:
            print("parse_view_online_book 失败，准备退出")
            result = {"reason": "parse_view_online_book failed"}
            self.save_result(code=self.BOOKCOMPFAIL, content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

    def parse_view_online_pay(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            if self.BUY_SUCC in body_text:
                print("购买该公司在线预览成功")
                if response.headers.getlist("Set-Cookie") == []:
                    cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
                    splited_cookie_src = cookie_src.split(";")
                    for i in splited_cookie_src:
                        if "JSESSIONID=" in i:
                            self.cookie = self.cookie_p.search(i).group(1)
                            print("爬取到的展示公司文件页Cookie: " + self.cookie)
                        elif "ROUTEID" in i:
                            self.route = self.route_p.search(i).group(1)
                            print("爬取到的展示公司文件页Route: " + self.route)
                else:
                    cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
                    route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
                    self.cookie = self.set_cookie_p.search(cookie_src).group(1)
                    print("爬取到的展示公司文件页Cookie: " + self.cookie)
                    self.route = self.set_route_p.search(route_src).group(1)
                    print("爬取到的展示公司文件页Route: " + self.route)
                self.next_url = "https://www.icris.cr.gov.hk/csci/cps_module.do"
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': 'https://www.icris.cr.gov.hk/csci/viewOnlinePay.do',
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                search_formdata={
                    "orderNo": self.order_no,
                    "DPDSInd": "true",
                    "fromViewOnline": "true",
                    "searchPage": "True",
                    "sCRNo": self.cr_num,
                    "unpaid": "false",
                    "nextAction": "cps_criteria"
                }
                yield scrapy.FormRequest(url=self.next_url, headers=headers, formdata=search_formdata,
                                         callback=self.parse_view_online_result)
            else:
                print("购买失败，准备退出")
                result = {"reason": "pay company record failed"}
                self.save_result(code=self.PAYCOMPFAIL, content=result)
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': self.next_url,
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
                yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)
        else:
            print("parse_view_online_pay失败，准备退出")
            result = {"reason": "parse_view_online_pay failed"}
            self.save_result(code=self.PAYCOMPFAIL, content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

    def parse_view_online_result(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print("预览在线结果成功，保存至文档中")
            file_path = self.download_root_path+self.comp_name_en+"/icris_online.html"
            json_path = self.download_root_path+self.comp_name_en+"/icris_online.json"
            result = {"reason": "Buy Successfully.", "orderId": self.order_no,"download_path":file_path}
            self.save_result(code=self.BUYSUCC, content=result)
            if not os.path.exists(self.download_root_path+self.comp_name_en):
                os.mkdir(self.download_root_path+self.comp_name_en)
            with open(file_path,"w") as f:
                f.write(body_text)
                f.close()
            json_result = self.parse_online_result(file_path)
            with open(json_path,"w") as f:
                f.write(json_result)
                f.close()
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)
        else:
            print("parse_view_online_result，准备退出")
            result = {"reason": "parse_view_online_result failed"}
            self.save_result(code=self.VIEWONLINEFAIL, content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

    def delete_useless(self,value):
        value = re.sub(self.empty_replace, " ", value)
        value = value.lstrip(" ")
        value = value.rstrip(" ")
        value = " ".join(value.split())
        return value

    def parse_online_result(self,html_path=None):
        result = dict()
        html = etree.parse(html_path, etree.HTMLParser())
        overall_table = html.xpath("//div[@id='PageContent']/table[3]")
        tables = overall_table[0].xpath("./tr/td/table")
        directors = overall_table[0].xpath("./tr/td/form[@name='DirectorList']/table/tr")
        # print(directors)
        reserve_directors = overall_table[0].xpath("./tr/td/form[@name='ReserveDirectorList']/table/tr")
        # print(reserve_directors)
        head_table = tables[0].xpath("./tr")
        # print(etree.tostring(head_table, pretty_print=True))
        # print(len(head_table))
        name_history = tables[1].xpath("./tr")
        # print(name_history)
        # print(len(name_history))
        registered_office = tables[2].xpath("./tr")
        # print(len(registered_office))
        share_capital = tables[3].xpath("./tr")
        # print(len(share_capital))
        particulars_of_company_secretary = tables[4].xpath("./tr")
        # print(len(particulars_of_company_secretary))
        particulars_of_receiver_and_Manager = tables[5].xpath("./tr")
        # print(len(particulars_of_receiver_and_Manager))
        particulars_of_liquidator = tables[6].xpath("./tr")
        # print(len(particulars_of_liquidator))
        # head table
        if len(head_table) != 0:
            for item in head_table:
                cols = item.xpath("./td")
                title = self.delete_useless(cols[0].xpath("./strong/font/text()")[0])
                value = cols[1].xpath("./font/text()")
                try:
                    if value == []:
                        value = self.delete_useless(cols[1].xpath("./span/text()")[0])
                    else:
                        value = self.delete_useless(value[0])
                except Exception as e:
                    traceback.print_exc()
                    value = "ERROR"
                result[title] = value

        # name history
        if len(name_history) != 0:
            result["Name History"] = {}
            actual_index = 1
            for index in range(1, len(name_history)):
                date_name_pair = name_history[index].xpath("./td")
                if len(date_name_pair) > 1:
                    # a normal pair
                    try:
                        effective_date = self.delete_useless(date_name_pair[0].xpath("./text()")[0])
                        name_used = self.delete_useless(date_name_pair[1].xpath("./span/text()")[0])
                        result["Name History"][actual_index] = {"Effective Date": effective_date,
                                                                "Name Used": name_used}
                        actual_index += 1
                    except Exception as e:
                        traceback.print_exc()
                        result["Name History"][actual_index] = {"Effective Date": "ERROR", "Name Used": "ERROR"}
                else:
                    try:
                        name_used = self.delete_useless(date_name_pair[0].xpath("./span/text()")[0])
                        result["Name History"][actual_index - 1]["Name Used"] = \
                        result["Name History"][actual_index - 1]["Name Used"] + " " + name_used
                    except Exception as e:
                        traceback.print_exc()
                        result["Name History"][actual_index - 1]["Name Used"] = \
                        result["Name History"][actual_index - 1][
                            "Name Used"] + " ERROR"

        # registered_office
        if len(registered_office) != 0:
            for item in registered_office:
                try:
                    office_pair = item.xpath("./td")
                    title = self.delete_useless(office_pair[0].xpath("./strong/font/text()")[0])
                    value = self.delete_useless(office_pair[1].xpath("./font/text()")[0])
                    result[title] = value
                except Exception as e:
                    traceback.print_exc()
                    result["Registered Office:"] = "ERROR"

        # share_capital
        if len(share_capital) != 0:
            result["Share Capital"] = {}
            for item in share_capital:
                try:
                    money_pair = item.xpath("./td")
                    result["Share Capital"][self.delete_useless(money_pair[0].xpath("./strong/text()")[0])] = self.delete_useless(
                        money_pair[1].xpath("./text()")[0])
                except Exception as e:
                    traceback.print_exc()
                    result["Share Capital"]["Issued:"] = "ERROR"
                    result["Share Capital"]["Paid-Up:"] = "ERROR"

        # List of Directors
        result["List of Director"] = {}
        for i in range(1, len(directors)):
            try:
                infos = directors[i].xpath("./td")
                index = self.delete_useless(infos[0].xpath("./div/font/text()")[0])
                en_name = self.delete_useless(infos[1].xpath("./font/text()")[0])
                cn_name = self.delete_useless(infos[2].xpath("./text()")[0])
                hk_id = self.delete_useless(infos[3].xpath("./font/text()")[0])
                passport = self.delete_useless(infos[4].xpath("./font/text()")[0])
                passport_region = self.delete_useless(infos[5].xpath("./font/text()")[0])
                director_type = self.delete_useless(infos[6].xpath("./font/text()")[0])
                result["List of Director"][index] = {"No": index, "Name in English": en_name,
                                                     "Name in Chinese": cn_name,
                                                     "HKID No./CR No.": hk_id, "Password No./China ID No.": passport,
                                                     "Passport Issuing Country/Region": passport_region,
                                                     "Director Type": director_type}
            except Exception as e:
                traceback.print_exc()
                result["List of Director"][str(i)] = {"No": "ERROR", "Name in English": "ERROR",
                                                      "Name in Chinese": "ERROR",
                                                      "HKID No./CR No.": "ERROR", "Password No./China ID No.": "ERROR",
                                                      "Passport Issuing Country/Region": "ERROR",
                                                      "Director Type": "ERROR"}

        # List of Reserve Directors
        if reserve_directors != []:
            result["List of Reserve Directors"] = {}
            for i in range(1, len(reserve_directors)):
                try:
                    infos = reserve_directors[i].xpath("./td")
                    index = self.delete_useless(infos[0].xpath("./div/font/text()")[0])
                    en_name = self.delete_useless(infos[1].xpath("./font/text()")[0])
                    cn_name = self.delete_useless(infos[2].xpath("./text()")[0])
                    hk_id = self.delete_useless(infos[3].xpath("./font/text()")[0])
                    passport = self.delete_useless(infos[4].xpath("./font/text()")[0])
                    passport_region = self.delete_useless(infos[5].xpath("./font/text()")[0])
                    reserve_director_nominated_by = self.delete_useless(infos[6].xpath("./font/text()")[0])
                    remark = self.delete_useless(infos[7].xpath("./font/text()")[0])
                    result["List of Reserve Directors"][index] = {"No": index, "Name in English": en_name,
                                                                  "Name in Chinese": cn_name,
                                                                  "HKID No./CR No.": hk_id,
                                                                  "Password No./China ID No.": passport,
                                                                  "Passport Issuing Country/Region": passport_region,
                                                                  "Reserve Director Nominated By": reserve_director_nominated_by,
                                                                  "remark": remark}
                except Exception as e:
                    traceback.print_exc()
                    result["List of Reserve Directors"][str(i)] = {"No": "ERROR", "Name in English": "ERROR",
                                                                   "Name in Chinese": "ERROR",
                                                                   "HKID No./CR No.": "ERROR",
                                                                   "Password No./China ID No.": "ERROR",
                                                                   "Passport Issuing Country/Region": "ERROR",
                                                                   "Reserve Director Nominated By": "ERROR",
                                                                   "remark": "ERROR"}

        # Particulars of Company Secretary
        if particulars_of_company_secretary != []:
            result["Particulars of Company Secretary"] = {}
            for i in range(1, len(particulars_of_company_secretary)):
                pair = particulars_of_company_secretary[i].xpath("./td")
                try:
                    result["Particulars of Company Secretary"][
                        self.delete_useless(pair[0].xpath("./b/strong/font/text()")[0])] = self.delete_useless(
                        pair[1].xpath("./font/text()")[0])
                except IndexError as e:
                    result["Particulars of Company Secretary"][
                        self.delete_useless(pair[0].xpath("./b/font/text()")[0])] = self.delete_useless(
                        pair[1].xpath("./font/text()")[0])

        # particulars_of_receiver_and_Manager

        return json.dumps(result)


    def parse_logout(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            self.update_icris_account()
            print("登出成功，爬虫即将结束程序。")
        else:
            # 登出失败，账号不要变更状态，否则会出现其他使用者无法正常使用该账号状态。
            print("登出失败，需要人工通过postman登出网站.公司名称:"+self.comp_name_en)

    def get_icris_account(self):
        conn = sqlite3.connect(self.account_db)
        cursor = conn.execute("SELECT username, password FROM icris WHERE status=0 AND balance>"+str(self.LOWBALANCE))
        records = list(cursor)
        if len(records) != 0:
            self.account = records[0][0]
            self.password = records[0][1]
            conn.execute("UPDATE icris SET status = 1 WHERE username='"+self.account+"'")
            conn.commit()
            conn.close()
            return True
        else:
            conn.close()
            return False

    def update_icris_account(self):
        conn = sqlite3.connect(self.account_db)
        # 2020-02-17 TODO 由于还未将余额检测功能补齐，或者由于还没有查询到余额就出错的情况，只更新status
        # TODO 对于后面加入余额检测功能时，需要加入判定是购买成功还是购买失败，购买失败不更新balance
        if self.account_balance != 0:
            conn.execute("UPDATE icris SET status = 2, balance=" +
                str(self.account_balance) + " WHERE username='" + self.account + "'")
            conn.commit()
            conn.close()
        else:
            conn.execute("UPDATE icris SET status = 0 WHERE username='" + self.account + "'")
            conn.commit()
            conn.close()
        self.account = ""
        self.password = ""
        self.account_balance = 0

    def save_result(self,code=None,content=None):
        f = open(self.temp_file + self.cr_num, 'w')
        f.write(str({"code":code,"content":content,"type":"buy"}))
        f.close()
