from scrapy.selector import Selector

body = '<html><body><span>good</span></body></html>'
