#!/usr/bin/python

from scrapy.cmdline import execute
execute()

