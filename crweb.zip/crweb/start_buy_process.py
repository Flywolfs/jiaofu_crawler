# coding=utf-8
import csv
import os
import time
import random
import sqlite3

def if_in_order(comp_name=None):
    conn = sqlite3.connect('order.db')
    c = conn.cursor()
    cursor = c.execute("SELECT orderid from order_comp where comp_name="+"\""+comp_name+"\"")
    res = cursor.fetchall()
    if len(res)>0:
        conn.close()
        return True
    else:
        conn.close()
        return False

def if_in_error(comp_name=None):
    conn = sqlite3.connect('order.db')
    c = conn.cursor()
    cursor = c.execute("SELECT reason from error_comp where comp_name=" + "\"" + comp_name + "\"")
    res = cursor.fetchall()
    if len(res) > 0:
        conn.close()
        return True
    else:
        conn.close()
        return False

compname_f = "compname_list.csv"
compnames_byte = csv.reader(open(compname_f,'r'),delimiter='$')
compnames = []

for compname in compnames_byte:
    compnames.append(compname[0].rstrip(','))

for compname in compnames:
    if if_in_error(compname) or if_in_order(compname):
        print("该公司已经被爬取，不需要再进行："+compname)
    else:
        os.system('scrapy crawl company_registry -a compname=\"'+compname+'\"')
        # 每个公司爬取时间间隔10-15秒，降低服务器压力
        time.sleep(random.randrange(10,15))

